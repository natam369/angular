import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormControl, FormBuilder, Validators, FormArray
} from '@angular/forms';
import { ConfirmedValidator } from './confirmed.validator';
@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {

  Credentials: FormGroup = new FormGroup({});
  constructor(private fb: FormBuilder) {
    this.Credentials = fb.group({

      password: ['', [Validators.required]],

      currentpassword: ['', [Validators.required]],


      confirm_password: ['', [Validators.required]]

    }, {

      validator: ConfirmedValidator('password', 'confirm_password')

    })
  }

  ngOnInit() {
  }

  onSubmit() {
    console.log(this.Credentials.get('currentpassword').value);
    console.log(this.Credentials.get('password').value);
    console.log(this.Credentials.get('confirm_password').value)
  }
  get f() {

    return this.Credentials.controls;

  }
}